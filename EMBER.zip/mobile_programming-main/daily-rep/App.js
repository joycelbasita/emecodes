import React, { useState } from 'react';
import { SafeAreaView, StyleSheet, Text, TextInput, View, Pressable, ScrollView } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Ionicons from '@expo/vector-icons/Ionicons';

const Tab = createBottomTabNavigator();

const colors = {
  background: '#101010',
  card: '#1d1d1f',
  primary: '#f07842',
  text: '#ffffff',
  muted: '#aaaaaa',
  border: '#333333',
};

function Button({ title, onPress, secondary = false }) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.button,
        secondary && styles.secondaryButton,
        pressed && styles.pressed,
      ]}
    >
      <Text style={styles.buttonText}>{title}</Text>
    </Pressable>
  );
}

/*
  HOME SCREEN
  Demonstrates:
  - View / Flexbox layout
  - Text
  - Button
  - Basic navigation
*/
function HomeScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.brand}>EMBER</Text>
        <Text style={styles.title}>Daily Workout</Text>
        <Text style={styles.subtitle}>
          A simple prototype for tracking exercises, sets, and reps.
        </Text>

        {/* Flexbox row */}
        <View style={styles.infoRow}>
          <View style={styles.infoBox}>
            <Text style={styles.infoNumber}>3</Text>
            <Text style={styles.infoLabel}>Exercises</Text>
          </View>

          <View style={styles.infoBox}>
            <Text style={styles.infoNumber}>12</Text>
            <Text style={styles.infoLabel}>Sets</Text>
          </View>

          <View style={styles.infoBox}>
            <Text style={styles.infoNumber}>36</Text>
            <Text style={styles.infoLabel}>Reps</Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Today's workout</Text>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>Quick Start</Text>
          <Text style={styles.cardText}>
            Log your exercises and record your reps for today's session.
          </Text>

          <Button
            title="Start Workout"
            onPress={() => navigation.navigate('Workout')}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

/*
  WORKOUT SCREEN
  Demonstrates:
  - TextInput
  - Text
  - Buttons
  - Flexbox rows
  - useState for simple input
*/
function WorkoutScreen() {
  const [exercise, setExercise] = useState('');
  const [reps, setReps] = useState('');

  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>Log Workout</Text>
        <Text style={styles.subtitle}>
          Enter one exercise and the number of reps.
        </Text>

        <View style={styles.card}>
          <Text style={styles.label}>Exercise</Text>
          <TextInput
            style={styles.input}
            placeholder="e.g. Push Ups"
            placeholderTextColor={colors.muted}
            value={exercise}
            onChangeText={setExercise}
          />

          <Text style={styles.label}>Reps</Text>
          <TextInput
            style={styles.input}
            placeholder="e.g. 10"
            placeholderTextColor={colors.muted}
            keyboardType="number-pad"
            value={reps}
            onChangeText={setReps}
          />

          <Button
            title="Save Exercise"
            onPress={() => {
              // Prototype only: no database is used.
              setExercise('');
              setReps('');
            }}
          />
        </View>

        {/* Another simple Flexbox row */}
        <View style={styles.row}>
          <View style={styles.smallCard}>
            <Text style={styles.cardTitle}>Exercise</Text>
            <Text style={styles.cardText}>
              {exercise || 'Not entered'}
            </Text>
          </View>

          <View style={styles.smallCard}>
            <Text style={styles.cardTitle}>Reps</Text>
            <Text style={styles.cardText}>
              {reps || '0'}
            </Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

/*
  HISTORY SCREEN
  Static prototype data.
  Demonstrates:
  - Text
  - View
  - Flexbox
  - Simple cards
*/
function HistoryScreen() {
  return (
    <SafeAreaView style={styles.screen}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>Workout History</Text>
        <Text style={styles.subtitle}>
          Previous sessions are shown as sample static data.
        </Text>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>September 25, 2026</Text>
          <Text style={styles.cardText}>Push Ups • 3 sets • 30 reps</Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>September 24, 2026</Text>
          <Text style={styles.cardText}>Squats • 3 sets • 36 reps</Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>September 23, 2026</Text>
          <Text style={styles.cardText}>Lunges • 2 sets • 20 reps</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

/*
  BASIC NAVIGATION
  Three simple screens:
  Home -> Workout -> History
*/
function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          headerShown: false,
          tabBarStyle: styles.tabBar,
          tabBarActiveTintColor: colors.primary,
          tabBarInactiveTintColor: colors.muted,
          tabBarIcon: ({ color, size }) => {
            const icons = {
              Home: 'home-outline',
              Workout: 'barbell-outline',
              History: 'time-outline',
            };

            return (
              <Ionicons
                name={icons[route.name]}
                size={size}
                color={color}
              />
            );
          },
        })}
      >
        <Tab.Screen name="Home" component={HomeScreen} />
        <Tab.Screen name="Workout" component={WorkoutScreen} />
        <Tab.Screen name="History" component={HistoryScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.background,
  },

  container: {
    padding: 20,
    gap: 16,
  },

  brand: {
    color: colors.primary,
    fontSize: 20,
    fontWeight: 'bold',
  },

  title: {
    color: colors.text,
    fontSize: 28,
    fontWeight: 'bold',
  },

  subtitle: {
    color: colors.muted,
    fontSize: 15,
    lineHeight: 22,
  },

  sectionTitle: {
    color: colors.text,
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 8,
  },

  /* Flexbox row: children are placed horizontally */
  infoRow: {
    flexDirection: 'row',
    gap: 10,
  },

  infoBox: {
    flex: 1,
    backgroundColor: colors.card,
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
  },

  infoNumber: {
    color: colors.primary,
    fontSize: 24,
    fontWeight: 'bold',
  },

  infoLabel: {
    color: colors.muted,
    fontSize: 12,
    marginTop: 4,
  },

  card: {
    backgroundColor: colors.card,
    padding: 18,
    borderRadius: 10,
    gap: 10,
    borderWidth: 1,
    borderColor: colors.border,
  },

  cardTitle: {
    color: colors.text,
    fontSize: 17,
    fontWeight: 'bold',
  },

  cardText: {
    color: colors.muted,
    fontSize: 14,
    lineHeight: 20,
  },

  label: {
    color: colors.text,
    fontSize: 14,
    fontWeight: 'bold',
    marginTop: 4,
  },

  input: {
    backgroundColor: '#111111',
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    padding: 12,
    color: colors.text,
    fontSize: 16,
    minHeight: 48,
  },

  button: {
    backgroundColor: colors.primary,
    minHeight: 48,
    paddingHorizontal: 18,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 6,
  },

  secondaryButton: {
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
  },

  buttonText: {
    color: colors.text,
    fontSize: 16,
    fontWeight: 'bold',
  },

  pressed: {
    opacity: 0.6,
  },

  /* Another Flexbox example */
  row: {
    flexDirection: 'row',
    gap: 10,
  },

  smallCard: {
    flex: 1,
    backgroundColor: colors.card,
    padding: 16,
    borderRadius: 10,
  },

  tabBar: {
    backgroundColor: colors.card,
    borderTopColor: colors.border,
    height: 60,
    paddingBottom: 6,
    paddingTop: 5,
  },
});

export default App;
