# EMBER — Basic MCO1 Prototype

EMBER is a simple React Native + Expo prototype for a **Daily Workout & Rep Tracker**.

This version is intentionally basic and mostly static so that the components and code are easy to explain during an MCO1 presentation.

## Main screens

1. **Home**
   - Shows the EMBER title and description.
   - Uses Flexbox to display sample workout statistics.
   - Has a **Start Workout** button.
   - The button demonstrates basic navigation to the Workout tab.

2. **Workout**
   - Uses two `TextInput` components:
     - Exercise name
     - Number of reps
   - Uses a button to clear the input fields.
   - Shows the entered values in simple cards.
   - Uses Flexbox for the Exercise/Reps row.

3. **History**
   - Shows three sample workout records.
   - The records are static sample data.
   - Uses simple `View`, `Text`, and Flexbox/card layouts.

## Components demonstrated

### View
`View` is the basic layout container in React Native.

Example:
```jsx
<View style={styles.card}>
  <Text>Workout information</Text>
</View>
```

### Text
`Text` displays labels and information.

Example:
```jsx
<Text style={styles.title}>Daily Workout</Text>
```

### TextInput
`TextInput` allows the user to enter information.

Example:
```jsx
<TextInput
  value={exercise}
  onChangeText={setExercise}
/>
```

### Button
The project uses a small custom `Button` component built with `Pressable`.

Example:
```jsx
<Button
  title="Start Workout"
  onPress={() => navigation.navigate('Workout')}
/>
```

### Flexbox
React Native uses Flexbox for arranging components.

Horizontal row:
```jsx
<View style={{ flexDirection: 'row' }}>
  <View style={{ flex: 1 }} />
  <View style={{ flex: 1 }} />
</View>
```

In this prototype, Flexbox is used for:
- Workout statistics
- Exercise/Reps cards
- Button and card layouts

### Basic Navigation
The app uses React Navigation with three bottom tabs:

```text
Home | Workout | History
```

The Home button also demonstrates navigation:

```jsx
navigation.navigate('Workout')
```

## Data behavior

This is a **prototype**, not a full database application.

- History uses static sample data.
- Workout input uses simple React `useState`.
- No login is required.
- No backend is required.
- No AsyncStorage is used.
- Closing/reloading the app does not save new workout data.

This makes the application easier to demonstrate and explain for MCO1.

## Run the project

From the `daily-rep` directory:

```bash
npm install
npx expo start
```

Then scan the QR code with Expo Go.

For browser preview:

```bash
npm run web
```

## Suggested MCO1 explanation

A simple explanation can follow this order:

1. **App purpose** — EMBER is a daily workout and rep tracker.
2. **Home screen** — demonstrates `View`, `Text`, `Button`, and Flexbox.
3. **Workout screen** — demonstrates `TextInput`, `useState`, `Button`, and Flexbox.
4. **History screen** — demonstrates static data using `View` and `Text`.
5. **Navigation** — React Navigation switches between Home, Workout, and History.
6. **Styling** — `StyleSheet.create()` keeps the design simple and organized.

The prototype intentionally avoids advanced features so each part can be explained individually.
